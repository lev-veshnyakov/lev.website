<?php
//lol
phpinfo();
?>
