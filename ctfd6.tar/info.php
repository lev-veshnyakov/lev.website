<?php
//lol2
phpinfo();
?>
